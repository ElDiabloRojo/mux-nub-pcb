

## kicad_freerouting-plugin

### Synopsis

FreeRouting round trip invocation:
* export board.dsn file from pcbnew
* auto route by invoking FreeRouting.jar
* import generated board.ses file into pcbnew

### Install

```
cd $HOME/.kicad_plugins
git clone https://github.com/random-builder/kicad_freerouting-plugin.git
```

### Operation

https://youtu.be/RDCAahIbB78
