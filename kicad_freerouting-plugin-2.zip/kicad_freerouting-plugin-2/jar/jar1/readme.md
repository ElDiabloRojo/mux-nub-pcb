
### origin

https://freerouting.org/freerouting/using-with-kicad

https://layouteditor.com/

### options

java -jar FreeRouting.jar -h

```
FreeRouting version 1.3.1
command line options are:
-de  provide design file
-di  design folder used in file dialog
-l   provide locale
-s   spectra session file is automatic saved on exit
-t   debug option
-white   white background
-h   this help
```
