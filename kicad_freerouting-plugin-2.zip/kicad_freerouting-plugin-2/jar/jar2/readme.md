
### origin

https://github.com/Engidea/FreeRoutingNew

https://github.com/Engidea/FreeRoutingNew/tree/master/deploy

### options

java -jar FreeRouting.jar -h

```
help option '-h' is gone 

```

some options still available

https://github.com/Engidea/FreeRoutingNew/blob/master/src/freert/main/MainOptions.java

